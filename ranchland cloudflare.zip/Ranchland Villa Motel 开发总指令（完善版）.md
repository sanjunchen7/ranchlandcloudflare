# Ranchland Villa Motel 官网与预订管理系统开发总指令（完善版）

## 0. 任务定义与最高优先级

请为加拿大 BC 省 Merritt 的 **Ranchland Villa Motel** 开发一个完整、可运行、可继续迭代并可用于正式业务验证的 Motel 官方网站，包含：

- 公共官网；
- 房间与房型展示；
- Availability 查询；
- Reservation Request；
- 内部管理员后台；
- 房间库存与 Maintenance；
- 每日房价与税费；
- 人工确认与信用卡担保结果记录；
- Email 通知与失败重发；
- 房间、房型及网站图片管理；
- 权限、安全、审计日志、测试、Migration 和 Seed。

这不是单纯的展示型网站，也不是静态 UI Mockup，而是一个小型 Motel 的官网＋Reservation Management System。

### 必须遵守的交付原则

1. 直接完成可运行项目，不要只生成静态页面或不可操作的界面。
2. 所有需要跨设备、跨访问或长期保存的数据必须进入真实后端数据库；不得用 `localStorage` 冒充业务持久化。
3. 上传图片必须使用可持续的文件／对象存储方案；不得把上传文件永久依赖 Git repository、浏览器本地状态或数据库 Blob。
4. 所有可见按钮、链接、筛选器、表单和后台操作必须有真实行为，不得出现死按钮或假成功。
5. 优先保证数据库、库存、预订、权限、防重复预订和邮件逻辑正确，再进行视觉润色。
6. 不得为了让演示看起来完整而伪造邮件发送、库存扣减、图片上传、登录、数据库写入或测试结果。
7. 遇到普通技术细节可以合理决定；遇到以下业务规则不得擅自改变：

- Request 不等于 Confirmed；
- Room 13 永不公开出租；
- 婴儿不计入 Maximum Occupancy；
- Early Check-in 只能申请，不能自动保证；
- V1 不接触完整信用卡号或 CVV；
- 不得编造税率、宠物费用、取消政策、No-show 费用、评分、评价或设施。

### 业务规则冲突时的优先顺序

1. 安全、隐私和信用卡数据限制；
2. 库存一致性与防止 Overbooking；
3. Reservation 状态与权限规则；
4. 价格快照、税费与审计；
5. 公共页面文案与视觉表现；
6. 其他体验优化。

---

## 1. Motel 基本信息

**Business Name**：Ranchland Villa Motel
**Address**：2379 Nicola Ave, Merritt, BC, Canada
**Call**：250-378-2140
**Text**：347-630-5076
**Email**：ranchlandmotel2379@gmail.com
**Front Desk**：24 hours
**Standard Check-in**：2:00 PM
**Earliest possible Early Check-in**：12:00 PM，必须由前台批准并视房态而定
**Standard Check-out**：11:00 AM
**初始公开起价**：Rooms from CA$119/night

公共网站显示：

> Standard check-in begins at 2:00 PM. Early check-in may be available from 12:00 PM by arrangement with the front desk and is subject to room availability.

不得让网站自动保证 12:00 PM 入住。

Check-out 文案：

> Check-out is at 11:00 AM. Earlier check-in or later check-out may be available by arrangement.

Late Arrival 文案：

> Guests arriving late are encouraged to contact the front desk in advance to arrange key pickup.

---

## 2. 网站定位与内容真实性

Ranchland Villa Motel 的定位是：

- Clean
- Comfortable
- Practical
- Affordable
- Convenient
- Road-trip friendly
- Family friendly
- Pet friendly
- Suitable for workers
- Suitable for longer stays

核心特点：

- 所有公开出租客房均位于一楼；
- 停车方便；
- 普通汽车、SUV、Pickup 可停车；
- 不宣传大型卡车、Semi Truck 或 Trailer Parking；
- 多种床型；
- 很多房间有厨房，但并非全部；
- 24-Hour Front Desk；
- Free Wi-Fi；
- Free Parking；
- 可携带宠物，但费用与可用房间需咨询前台。

不得制造或暗示不存在的：

- 豪华设施；
- 星级；
- 虚假评分或评价；
- Awards；
- 固定 Pet Fee；
- Cancellation Policy；
- No-show Fee；
- Instant Confirmation；
- 实际未提供的 Amenities；
- Motel 的 physical wheelchair accessibility。

---

## 3. 视觉风格与 Mobile First

公共官网整体采用 **Warm / Friendly / Clean / Practical BC Roadside Motel**，以暖黄色建立亲切、轻松、适合公路旅行和家庭经营小 Motel 的视觉识别，但不得牺牲干净、可信和容易使用的专业感。

小 Motel 不等于不需要 Professional。专业感应来自真实照片、清晰信息、可靠预订流程、一致的排版和足够的可读性，而不是依赖深蓝或豪华酒店风格。

### 公共官网色彩角色

- **暖米白／Warm Off White**：作为主要页面背景，保持干净，并突出真实房间与 Motel 照片；
- **金黄／芥末黄／暖黄色**：作为主要品牌色，用于品牌区域、部分 Hero 或 Availability 区域、主要 CTA、重点信息及适量装饰；
- **深炭灰／深棕灰**：用于正文、导航和主要标题，确保稳定与可读性；
- **低饱和灰蓝**：仅作为可选辅助色，用于少量链接或辅助信息，不再作为主要品牌色。

暖黄色是主导识别色，但不是把所有背景都染成黄色。大面积内容区仍以暖米白和中性色为主，避免视觉疲劳。

### CTA 与可读性

- 主要 CTA 优先采用暖黄色背景＋深色文字；
- 不得使用白字配浅黄色按钮；
- 不得使用黄色正文文字配白色或暖米白背景；
- 正文、按钮、表单、Focus、房态和动态提示必须满足足够对比度；
- Available、Held、Confirmed、Error、Success 等状态继续使用清楚的语义颜色，不得为了统一品牌而全部改成黄色。

### 黄色使用禁忌

避免：

- 大面积高饱和柠檬黄；
- 黄色、橙色和棕色同时大量使用造成陈旧感；
- 每个卡片、标题和区块都使用黄色；
- 为了亲切而加入过多手绘、圆角或可爱装饰；
- 黄色背景影响房间照片、房价、表单和预订信息的阅读。

公共官网最终应感觉温暖、友好、实用、可信，而不是廉价、幼稚或过度复古。

避免：

- Luxury hotel 风格；
- 过度渐变；
- 过多动画；
- 玻璃拟态；
- 过度可爱的设计；
- 大量无意义装饰；
- 大量文字压过房间和 Motel 照片。

公共网站必须 Mobile First。手机端应特别容易完成：

- Call Motel；
- Text Motel；
- Check Availability；
- Request Reservation；
- 查看地址；
- 打开地图导航。

顶部可以提供：Call、Text、Check Availability。

管理后台以 Desktop 为优先，采用中性、清晰、商业型界面，以中性背景、深色文字和明确状态色为主；暖黄色只保留少量品牌识别，不得影响数据表格、日历和长时操作的可读性。后台仍需满足基本响应式、可访问性和无横向溢出要求。

---

## 4. 公共页面与核心用户流程

至少建立：

- Home
- Rooms
- Availability / Reservation
- Contact
- FAQ

公共文案统一使用：

- Check Availability
- Request Reservation
- Reservation Request
- Pending Confirmation
- Confirmed Reservation
- Request This Room Type

避免使用：

- Book Now
- Instant Booking
- Instant Confirmation

“Request This Room Type”不得让客人误以为已经选择或锁定具体房号。

### 核心 Guest 流程

```text
Visit website
→ See actual motel and room photos
→ Select dates and guests
→ Check room types currently available to request
→ Review room gallery and estimated price
→ Select preferred room type
→ Request kitchen if needed
→ Request early check-in if needed
→ Submit Reservation Request
→ Receive Request Number and not-confirmed notice
→ Front desk reviews
→ Guest receives confirmation only after staff confirms
```

### 查询到表单的连续性

从 Availability 结果进入 Reservation Form 时，必须保留：

- Check-in / Check-out；
- Adults / Children age 2+ / Infants under 2；
- Preferred Room Type；
- Kitchen Preference；
- 已选择的其他查询条件。

提交失败时保留用户已填写内容。提供 Loading、Empty、Error、Success 和库存变化状态，不得只实现成功路径。

---

## 5. Home 页面结构

推荐顺序：

1. Hero
2. Availability Bar
3. Why Stay Here
4. Featured Rooms with Photos
5. Amenities
6. Photo Gallery
7. Kitchen Rooms
8. Ground-Floor / Parking
9. Pet-Friendly
10. Location
11. Contact CTA

Hero 不得只有固定写死图片，必须能够从 Admin 更换。

首页 Rooms Preview 显示 3–5 张 Room Type Cards，每张包含：

- Room Photo；
- Room Type Name；
- Beds；
- Kitchen 信息；
- From Price；
- View Room／Request This Room Type。

Home Availability Widget 字段：

- Check-in；
- Check-out；
- Guests；
- Check Availability。

返回结果包含：

- Photo；
- Room Type；
- Beds；
- Kitchen 信息；
- 当前日期范围内的价格或 From Price；
- Estimated Total（如已实现完整报价）；
- Request This Room Type。

---

## 6. Rooms 页面与房间卡片

每一种公开 Room Type 都是视觉重点，必须支持多张照片，而不是只有一张固定图片。

每个房型包含：

- Large Cover Photo；
- Thumbnail Gallery；
- Room Type Name；
- Beds；
- Capacity；
- Kitchen；
- Amenities；
- From CA$119/night 或当前适用起价；
- Request This Room Type。

示例：

```text
Queen Room
[LARGE ROOM PHOTO]
[photo] [photo] [photo] [photo]
1 Queen Bed
Up to 2 guests
Kitchen available in select rooms
Free Wi-Fi
Free Parking
From CA$119/night
[Request This Room Type]
```

公共网站优先显示 Room Type Gallery。Room Type 图片可以来源于具体房间，但不一定向客人暴露具体房号。

显示：

> Room layout and furnishings may vary slightly by room.

避免让客人误认为一定得到照片完全相同的具体房间。

---

## 7. Amenities、Kitchen 与 Pet 文案

基础 Amenities：

- Free Wi-Fi
- Free Parking
- Air Conditioning
- Heating
- TV / Cable
- Microwave
- Refrigerator
- Coffee Maker
- Hair Dryer
- Bathtub / Shower
- Ground-Floor Rooms
- 24-Hour Front Desk
- Kitchen Rooms Available
- Pet-Friendly Rooms Available

厨房房间通常包括：

- Microwave
- Stove
- Oven
- Refrigerator
- Coffee Maker
- Basic cookware

不是所有房间都有厨房。公共文案：

> Kitchen-equipped rooms are available in select rooms. Please let us know if you prefer a kitchen when making your reservation request.

宠物公共文案：

> Pet-friendly rooms are available. Please contact the front desk for current pet fees and availability.

Reservation Form 选择 Pets = Yes 时显示：

> Pet-friendly rooms are subject to availability. The front desk will confirm any applicable pet fee.

Admin 可以记录 Pet、Pet count、Pet notes、Pet fee。V1 不在前端自动计算或承诺固定 Pet Fee。

---

## 8. 房间库存与初始化数据

公开出租共 **17 间**。

Room 13 是地下室，不对外出租：

- 不显示在官网；
- 不进入 Public Availability；
- 不允许 Public Reservation；
- 不进入任何公开可预订数量；
- 数据库保留为 `INTERNAL / NOT FOR RENT`；
- 仅授权后台可查看或维护。

建立 `rooms`，每间可独立配置：

- room_number
- room_type_id
- beds
- kitchen
- max_occupancy
- public
- bookable
- active
- status
- connecting_room
- notes
- default_rate
- cover_image／photo gallery 关系

不得把 Maximum Occupancy、Kitchen 或公开状态硬编码在页面中。

### 初始化房间

| Room | Beds | Kitchen | 其他 |
| --- | --- | --- | --- |
| 1 | 1 Queen | Yes | Connecting Room: Room 2，独立入口 |
| 2 | 1 Queen | Yes | Connecting Room: Room 1，独立入口 |
| 3 | 2 Double + 1 Queen | Yes | Maximum Occupancy: 5 |
| 4 | 1 Queen | No |  |
| 5 | 1 Queen | Yes |  |
| 6 | 1 Queen | Yes |  |
| 7 | 1 Queen | Yes |  |
| 8 | 2 Queen | Yes |  |
| 9 | 2 Double | Yes |  |
| 10 | 1 Queen | No |  |
| 11 | 1 Queen | Yes |  |
| 12 | 1 Queen | Yes |  |
| 13 | Basement | N/A | Public=False，Bookable=False，Status=INTERNAL |
| 14 | 1 Queen | Yes |  |
| 15 | 2 Double | No |  |
| 16 | 2 Double | No |  |
| 17 | 1 Queen | Yes |  |
| 18 | 1 Double | No |  |

Room 1／2 可以分别出租，两房之间存在连接门。公共文案：

> Connecting rooms may be available upon request. Please contact the front desk for availability.

---

## 9. Public Room Type、Occupancy 与 Infant Rule

客人不要直接选择 Room 5、Room 8 等具体房号。客人选择：

### Queen Room

- 1 Queen Bed
- Kitchen available in select rooms
- 初始最多 2 guests

### Double Room

- 1 Double Bed
- 初始最多 2 guests

### Two Double Beds

- 2 Double Beds
- Kitchen available in select rooms
- 初始最多 4 guests

### Two Queen Beds

- 2 Queen Beds
- Kitchen included
- 初始最多 4 guests

### Three-Bed Room / Family Room

- 2 Double Beds + 1 Queen Bed
- Kitchen included
- Maximum 5 guests

具体房间号由前台安排。后台可以修改容量，不得硬编码。

### 入住人数计算

Reservation Form 分开记录：

- Adults
- Children age 2+
- Infants under 2

Maximum Occupancy 只按：

```text
adults + childrenAge2Plus
```

2 岁以下婴儿不占容量，但仍保存数量。

验证规则：

- Adults 至少为 1；
- Children 与 Infants 不得为负数；
- `adults + childrenAge2Plus` 不得超过所申请房型的可用房间容量；
- 不得仅靠前端的 HTML `max` 或 `min` 验证，后端必须重新验证。

---

## 10. Kitchen Preference 查询规则

Reservation Form 提供：

- No preference
- Prefer a kitchen
- Kitchen required

显示：

> Kitchen availability is subject to confirmation by the motel.

逻辑必须区分：

- **No preference**：有厨房和无厨房房间都可参与计算；
- **Prefer a kitchen**：只是偏好，不得把无厨房房间从可用库存中排除；后台应突出该偏好；
- **Kitchen required**：只有 `kitchen = true` 的房间可参与该 Request 的可用库存与后续分房；后台必须突出显示为硬性要求。

如果前台给 `Kitchen required` 的预订分配无厨房房间，系统必须阻止，除非未来另有明确授权规则；V1 不允许静默绕过。

---

## 11. 图片系统与媒体数据模型

图片是网站的重要内容资产，不能只是临时装饰或固定 Hero。

必须支持：

- 首页 Hero；
- 首页 Gallery；
- 每个 Room Type 多张照片；
- 每个具体 Room 多张照片；
- Admin Media Library；
- Upload、Preview、Delete、Reorder、Set Cover、Alt Text、Caption；
- Public／Internal 权限；
- 响应式图片与多尺寸优化。

### 首页照片

Hero 建议比例 16:9 或 21:9，用于：

- Motel 外观；
- Motel 招牌；
- 建筑＋停车区域。

Hero 必须能从 Admin 更换。

首页提供 **Explore Ranchland Villa Motel**，展示 4–8 张图片：

- Motel exterior
- Parking area
- Queen room
- Double room
- Kitchen
- Bathroom
- Three-bed room
- Motel entrance

Desktop 使用 Grid／Masonry／Gallery；Mobile 使用适合 horizontal swipe 的布局，不得造成整个页面横向溢出。点击图片打开 Lightbox。

### Room Type 与具体 Room 照片

Queen Room、Two Double Beds、Two Queen Beds、Three-Bed Room 等每个公开房型均支持：

- Main room photo
- Bed photo
- Kitchen photo
- Bathroom photo
- Entrance / parking photo

每个具体房间也允许独立上传，例如 Room 5 可以有 main、bed、kitchen、bathroom 等照片。

Admin 路径示例：

```text
Rooms → Room 5 → Photos
```

支持 Upload、Delete、Reorder、Set Cover Image、Add Alt Text、Add Caption、Mark Public / Internal。

### 建议数据模型

`media`：

- id
- storage_key / file_path / object_url
- original_filename
- mime_type
- width
- height
- alt_text
- caption
- created_at

`room_media`：

- room_id
- media_id
- sort_order
- is_cover
- is_public

`room_type_media`：

- room_type_id
- media_id
- sort_order
- is_cover
- is_public

`site_media`：

- media_id
- placement／section
- sort_order
- is_cover（如适用）
- is_public

Placement 支持 Hero、Exterior、Parking、Contact、Homepage Gallery 等。

### 媒体公开规则

1. Internal 照片不得因为被分配到 Room Type 或 Homepage 就自动公开。
2. 公共网站只能读取明确标记为 Public 的媒体及公开关联。
3. Internal 媒体需要授权访问，不得仅通过隐藏链接假装安全。
4. 公共 Alt Text、Caption 不得暴露内部备注或不该公开的房号信息。
5. 每个 Room 和每个 Room Type 最多一张有效 Cover；设置新 Cover 时原子地取消旧 Cover。
6. 删除仍被引用的媒体时必须提示影响范围；采用明确的删除或软删除策略，不得留下破损公共图片。
7. 拖拽排序必须持久化 `sort_order`，刷新后不得恢复旧顺序。

### 上传与优化

支持 JPEG、JPG、PNG、WebP。HEIC → server-side conversion 可作为增强，不是 V1 硬性要求。

上传后生成或按需生成：

- Thumbnail
- Medium
- Large
- Original

公共网站不得直接加载 8–15 MB 原图作为列表缩略图。

必须实现或预留：

- Lazy Load；
- Responsive `srcset`；
- Modern format；
- 合理压缩；
- 明确宽高以避免 CLS；
- Cover 使用适当 crop／`object-fit: cover`；
- Lightbox Full View 不裁掉主体。

上传必须校验真实 MIME、扩展名、文件大小与权限；不能仅相信浏览器声明。文件名不得直接决定存储路径，避免路径覆盖与遍历。

### Placeholder

真实照片尚未上传时显示干净 Placeholder，例如：

> Queen Room Photo Coming Soon

不得使用可能误导客人的 AI 生成房间照片冒充真实 Motel 房间。如使用临时示意图，必须明确标注并与真实照片区分。

### Lightbox

支持：

- Previous
- Next
- Close
- Caption
- Keyboard navigation
- Mobile swipe
- Focus management
- Close button、Escape 等明确退出方式

---

## 12. 日期、时区与通用验证

所有与营业日期、入住、退房、Hold 过期和“今天”有关的逻辑，统一以 Motel 所在地时区 **America/Vancouver** 解释；数据库时间戳可采用 UTC，但必须明确转换。

基本规则：

- Check-in 不得早于 Motel 当地当天；
- Check-out 必须晚于 Check-in；
- 入住按住宿夜计算；
- 退房当天不计入占用夜；
- Preferred Check-in Time 不得早于 12:00 PM；
- Standard Check-in 为 2:00 PM；
- 早于 2:00 PM 永远是 Early Check-in Request；
- 晚到时间可以作为 Late Arrival 信息保存，不自动改变标准入住规则；
- 所有验证必须同时在客户端与服务端执行。

---

## 13. Availability 的统一计算规则

Availability 必须根据以下数据计算：

- Public、Bookable、Active 房间；
- Room Type；
- Maximum Occupancy；
- Kitchen Preference；
- Confirmed Reservations；
- Checked-in Reservations；
- 有效 Room Holds；
- Maintenance／Out of Service。

Room 13 及其他非公开、不可预订、停用房间必须被排除。

### 占用区间

采用半开区间：

```text
[check_in_date, check_out_date)
```

两个住宿区间重叠的判断统一为：

```text
existing.check_in_date < new.check_out_date
AND existing.check_out_date > new.check_in_date
```

因此：

```text
Guest A：Nov 10 → Nov 12
Guest B：Nov 12 → Nov 14
```

合法，不冲突。

### 哪些记录阻止库存

| 状态／记录 | 是否阻止对应房间再次被分配 |
| --- | ---: |
| REQUESTED | 否 |
| REVIEWING | 否 |
| AWAITING_GUARANTEE，无有效 Hold | 否 |
| AWAITING_GUARANTEE，有有效 Hold | 是 |
| CARD_GUARANTEED，无有效 Hold | 否 |
| CARD_GUARANTEED，有有效 Hold | 是 |
| CONFIRMED | 是 |
| CHECKED_IN | 是 |
| 有效 Maintenance / Out of Service | 是 |
| DECLINED | 否 |
| CANCELLED | 否 |
| CHECKED_OUT | 否 |
| NO_SHOW | 否 |
| 已过期或已释放 Hold | 否 |

同一笔 Reservation 的有效 Hold 与 Confirmed 占用不得被重复计算为两间库存。Confirm 后应将 Hold 转为正式占用或标记为已消费。

### 公共查询的语义

公共查询返回的是“当前可以申请该房型”，不是实时锁房，也不是确认预订。

查询步骤：

1. 找出符合 Public、Bookable、Active、Room Type、Capacity 和 Kitchen Required 条件的房间；
2. 排除整个日期范围内任一晚被 Confirmed、Checked-in、有效 Hold 或 Maintenance 占用的房间；
3. 按 Room Type 聚合可申请数量和最低适用价格；
4. Prefer Kitchen 不排除无厨房房，但可以在结果中显示厨房偏好提示；
5. 提交 Request 时重新验证输入与当前库存，但仍不锁房；
6. 如果提交时库存已变化，应明确提示，不得假装仍保留房间。

公共文案可使用：

> Availability is subject to front desk review. Submitting a request does not reserve or confirm a room.

---

## 14. Inventory Hold 规则

`AWAITING_GUARANTEE` 阶段，前台可以 Hold Room，也可以 Release Hold。

每个 Hold 至少记录：

- room_id
- reservation_id
- start_date
- end_date
- status
- created_by
- created_at
- hold_expires_at
- released_at
- released_by
- release_reason

规则：

1. Hold 必须覆盖明确住宿区间；
2. 只有未过期、未释放、未消费的 Active Hold 才占用库存；
3. 创建或延长 Hold 时必须重新检查所有冲突；
4. Hold 到期后不再阻止 Availability；
5. 可以使用后台任务自动释放，也可以查询时按 `hold_expires_at` 判定失效，但所有模块必须采用同一规则；
6. Release、Expire、Confirm、Decline、Cancel 后及时解除或终止对应占用；
7. Hold 不是 Confirmed Reservation，不得向客人暗示已经确认；
8. 未 Hold 的 Awaiting Guarantee 请求不保留房间，前台界面应明确显示这一风险。

---

## 15. Reservation Form 与 Request 创建

字段：

- Check-in Date
- Check-out Date
- Preferred Check-in Time
- Adults
- Children age 2+
- Infants under 2
- Pets
- Pet Count／Pet Notes（选择 Yes 时可填写）
- Preferred Room Type
- Kitchen Preference
- First Name
- Last Name
- Mobile Phone
- Email
- Vehicle Type optional
- Special Requests optional

Vehicle：

- Car
- SUV
- Pickup
- Other

按钮使用 **Request Reservation**。

表单附近清楚显示：

> Submitting this form is a reservation request only. Your room is not confirmed until you receive a confirmation from Ranchland Villa Motel.

Early Check-in 早于 2:00 PM 时显示：

> Early check-in from 12:00 PM may be available by arrangement. The motel will confirm whether your requested arrival time can be accommodated.

Early Check-in 永远只记录为 `REQUESTED`，不是自动批准。

### 提交规则

1. 服务端重新验证日期、人数、房型、Kitchen Required、联系信息和公开库存；
2. 使用服务端生成的唯一 Reservation Request Number；
3. 防止重复点击、网络重试或刷新造成重复 Request，可采用 Idempotency Key；
4. Request 创建不自动分房，不自动 Confirm，不自动收卡；
5. 保存请求的报价版本或预估价格，但明确其不是最终确认价格；
6. 创建成功后发送 Request Received 邮件；邮件失败不回滚已创建的 Request。

成功后显示：

# Reservation Request Received

> Thank you for choosing Ranchland Villa Motel.
> > >
> Your reservation request has been received and is being reviewed by our front desk.
> > >
> Your reservation is not confirmed yet.
> > >
> We may contact you to obtain a valid credit card to guarantee your reservation.
> > >
> Once your reservation is confirmed, you will receive a confirmation email.

同时显示 Reservation Request Number。

---

## 16. Reservation 状态机

状态：

- REQUESTED
- REVIEWING
- AWAITING_GUARANTEE
- CARD_GUARANTEED
- CONFIRMED
- CHECKED_IN
- CHECKED_OUT
- DECLINED
- CANCELLED
- NO_SHOW

### 正常主流程

```text
REQUESTED
→ REVIEWING
→ AWAITING_GUARANTEE
→ CARD_GUARANTEED
→ CONFIRMED
→ CHECKED_IN
→ CHECKED_OUT
```

### 允许的旁路

- REQUESTED／REVIEWING → DECLINED；
- 业务允许的阶段 → CANCELLED；
- CONFIRMED → NO_SHOW；
- AWAITING_GUARANTEE → CONFIRMED 只能通过 ADMIN 的 Confirm Without Card Guarantee Override；
- 其他跳转必须被阻止，不得由前端任意传状态值。

### 状态转换前置条件

- Confirm 前必须已分配具体 Room；
- Confirm 前必须重新检查 Assigned Room 全日期冲突；
- Confirm 通常要求有效 `VERIFIED` 或 `PREAUTHORIZED` Guarantee；
- Admin Override 必须记录 user、timestamp、reason；
- Check-in 只能从符合业务条件的 Confirmed Reservation 进入；
- Check-out 只能从 Checked-in 进入；
- Cancel、Decline、No-show、Check-out 后释放相关 Hold 和库存；
- Change Dates、Change Room 视为高风险操作，必须重新验证容量、Kitchen Required、冲突和价格；
- 不得仅通过隐藏按钮保证规则，后端必须验证当前状态和目标状态。

### Reservation 与 Guarantee 的一致性

不得允许 Reservation 显示 `CARD_GUARANTEED`，而 Guarantee 记录仍为 Pending。

可以采用以下任一实现，但全项目只能使用一种主逻辑：

1. Reservation 的担保相关状态由有效 Guarantee 记录自动驱动；或
2. 简化 Reservation 状态，把担保进度完全放在 Guarantee 子资源中。

不得让管理员分别手工维护两套互相矛盾的状态。

---

## 17. Room Assignment 与后台修改

Request 阶段没有具体 room_number 也可以。

Admin Review：

1. 选择符合条件的 Room；
2. 验证 Public／Bookable／Active、容量、Kitchen Required；
3. 检查 Confirmed、Checked-in、Active Hold、Maintenance 冲突；
4. 分配 Room；
5. 处理 Early Check-in；
6. 记录 Guarantee；
7. Confirm；
8. 保存价格快照和最终 Confirmed Check-in Time；
9. 发送 Confirmation Email。

修改日期、换房、修改价格、批准 Early Check-in、Confirm、Cancel、No-show 等必须进入 Audit Log。

确认后如需修改日期、房间或价格，不得静默覆盖旧业务事实；应保存新的价格／确认版本并保留历史，必要时发送 Updated Confirmation。

---

## 18. 房价、报价与 Price Snapshot

公开初始文案：

> Rooms from CA$119/night

后台支持 **Room + Date 单独价格**。例如：

```text
Room 5 / Dec 1 / CA$129
Room 5 / Dec 2 / CA$139
Room 8 / Dec 2 / CA$159
```

建立 `room_daily_rates`，Admin 提供 Calendar／Grid，支持：

- 单日修改；
- 日期范围；
- 单房间；
- 多房间批量；
- Default rate；
- Weekend rate；
- Special date rate。

### 报价规则

1. 每个住宿夜按 Room＋Date 确定价格，不直接把总晚数乘一个固定价格；
2. Request 阶段显示的价格必须标为 Estimated Price／Estimated Total，除非业务明确提供锁价；
3. 查询后、Confirm 前房价发生变化时，以 Confirm 时由前台确认的报价为准；
4. Admin 修改日期后，应重新逐晚计算，并显示价格变化；
5. Admin 可以调整价格，但调整必须记录 Audit Log；
6. 不得把 Request 阶段的 From Price 当成最终承诺总价；
7. 前端显示 Subtotal、Taxes、Approved Fees、Total；后台可查看逐晚价格和税种明细。

### Price Snapshot

Confirm 时保存：

- 每晚日期；
- 每晚 Room Rate；
- Subtotal；
- 各税种与税额；
- Approved Fees；
- Total；
- 当前报价版本；
- 确认人或系统时间。

以后修改 Daily Rate 或 Tax Rule 不得影响已经确认的旧 Reservation。

确认后修改日期、房间、价格或费用时：

- 生成新的 Price Snapshot／Confirmation Version；
- 保留旧版本；
- 记录修改原因与操作人；
- 如影响客人确认信息，支持发送 Updated Confirmation，不得把旧价格再次发送给客人。

---

## 19. Taxes 与费用计算

不要永久硬编码税率。

Tax Settings：

- GST
- Accommodation PST
- MRDT
- Other applicable tax

字段：

- Name
- Enabled
- Rate
- Effective Date
- End Date
- 必要的计算顺序／适用范围配置

正式上线前由实际业务方填写适用税率。不得自行编造。

计算规则必须明确并统一：

- 税费按各住宿夜对应的有效规则计算；
- 税率有效期不得无意重叠；
- 需明确每种税的计算基础及 Approved Fees 是否计税；无法从业务资料确定时保留配置，不擅自假设；
- 确定统一 rounding 规则，并在 API、公共报价、后台和邮件中使用相同结果；
- 前端主要显示 Subtotal、Taxes、Total；
- 后台可以查看具体税种、计算基础和金额。

---

## 20. Payment Philosophy 与信用卡安全

默认：

> Payment: Pay at Property

V1 不做 Online Payment，不创建 Card Number 输入框，不集成 Stripe Checkout、Moneris 或自动扣款。

信用卡只用于 Reservation Guarantee，主要防 No-show。

网站绝不能保存或接收：

- Full card number
- CVV
- CVC

不得把卡号或 CVV 写入：

- Notes
- Logs
- Database
- Analytics
- Email
- Error traces

### 人工担保流程

```text
Front Desk Calls Guest
→ Guest provides card information by phone
→ Existing credit-card provider / terminal / virtual terminal handles card
→ Website receives no full card data
→ Staff records guarantee result
→ CARD_GUARANTEED
→ Staff confirms
→ CONFIRMED
→ Automatic Email
→ Staff manually sends SMS
→ Guest arrives
→ Pay at Property
```

Guarantee Data 只保存：

- guarantee_status
- card_brand optional
- card_last4 optional
- guarantee_amount optional
- verification_date
- verified_by
- provider_reference optional
- notes

严禁完整卡号与 CVV。后台输入、日志和异常处理需避免意外记录敏感认证数据。

Guarantee Method：

- Card verified
- Pre-authorized
- Front desk override
- No guarantee

系统本身不执行 Pre-Authorization，只记录结果。

### Future Payment Integration

预留 `PaymentGuaranteeService` 抽象：

- V1：`ManualGuaranteeService`
- Future：Hosted Tokenization／Secure Guarantee Link／Provider API

不要把支付逻辑写死在 Reservation Controller。未来扩展不得迫使 V1 保存敏感卡数据。

---

## 21. Early Check-in 与 Late Arrival

Reservation Form 的 Preferred Check-in Time 默认 2:00 PM，允许申请 12:00 PM 以后的时间。

如果早于 2:00 PM：

- 保存为 Early Check-in Requested；
- 不自动批准；
- 不改变库存占用区间；
- Admin 中突出显示。

管理员处理：

- Early Check-in：Approved / Not Approved
- Confirmed Check-in Time：具体时间

Confirmation Email 必须显示最终批准的 Confirmed Check-in Time，而不是仅显示客人申请时间。

标准说明：

> Standard check-in begins at 2:00 PM. Early check-in may be available from 12:00 PM when approved by the front desk.

若已批准 12:00 PM：

> Confirmed Check-in: 12:00 PM

Late Arrival：

> If you expect to arrive late, please contact the front desk in advance to arrange key pickup.

---

## 22. Cancellation、No-show 与公共政策边界

当前不建立公开 Cancellation Policy，不编造：

- 24 hours
- 48 hours
- non-refundable
- first night penalty

公共网站只写：

> If your travel plans change, please contact the motel as soon as possible.

Admin 支持 CANCELLED 与 NO_SHOW，但不自动扣款。

No-show 不自动产生费用，不自动调用卡提供商，不触发自动收费。取消、No-show 后释放相关 Hold 和库存，并保留历史与审计记录。

---

## 23. Email 通知、失败处理与防重复

自动发送：

### A. Reservation Request Received

同时通知 Guest 和 Motel Front Desk，包含：

- Request Number
- Guest Name
- Dates
- Requested Check-in Time
- Guest Count
- Room Type
- Motel Address
- Call
- Text
- Email
- Not Confirmed Notice

### B. Confirmation Email

包含：

- Ranchland Villa Motel
- 2379 Nicola Ave, Merritt, BC, Canada
- Reservation Number
- Guest
- Check-in Date
- Confirmed Check-in Time
- Check-out Date
- Guests
- Room Type
- Assigned Room Number
- Kitchen
- Nightly Rate
- Subtotal
- Taxes
- Approved Fees
- Total
- Payment: Pay at Property
- Call: 250-378-2140
- Text: 347-630-5076
- Email: ranchlandmotel2379@gmail.com
- Standard Check-in／Early Check-in 说明
- Late Arrival 说明
- Check-out: 11:00 AM

Payment Copy：

> A valid credit card may be required to guarantee your reservation.

卡担保已确认：

> Reservation guarantee verified by front desk.

### 邮件可靠性规则

1. Email 失败不取消或回滚 Reservation；
2. Email Log 标记 FAILED，支持 Resend；
3. Confirm 操作与 Email 发送解耦，避免因邮件服务失败导致库存状态不一致；
4. 防止连续点击 Confirm、任务重试或网络重试发送重复邮件；
5. 使用 Reservation ID＋Email Type＋Confirmation Version 等幂等依据；
6. 重要修改后发送明确标记为 Updated Confirmation 的新版本邮件；
7. 不发送完整卡号、CVV、内部备注或敏感日志；
8. 开发生产前需要真实可用的邮件服务配置；没有配置时必须诚实显示未配置或发送失败，不得伪造成功。

---

## 24. SMS

V1 不自动发送 SMS。

Admin 提供 **Copy SMS**，例如：

> Ranchland Villa Motel: Your reservation RV-20261110-001 is confirmed for Nov 20–22. Check-in: 2:00 PM. Address: 2379 Nicola Ave, Merritt, BC. For late arrival, contact the front desk at 250-378-2140.

如果 Early Check-in 已批准，SMS 使用最终 Confirmed Check-in Time，例如 12:00 PM，而不是客人原始申请或默认时间。

---

## 25. Admin Authentication 与权限矩阵

角色：

- ADMIN
- FRONT_DESK

必须实现真实可用的后台登录，不得只做登录页 Mockup。

默认提供：

- `/admin`：已登录则进入 Dashboard，未登录则跳转登录页；
- `/admin/login`：管理员和前台员工共用登录入口；
- 安全的账号密码登录或平台实际支持的认证方式；
- Logout、Session 过期和登录失败反馈；
- 安全 Cookie／Session、Password Hash、Rate Limit 和服务端授权。

首个 ADMIN 必须通过安全初始化流程创建，例如一次性 Setup 命令或受保护的首次设置流程。不得在代码、公共 README 或 `.env.example` 中写死可使用的公共密码；密码只保存哈希，并支持后续修改或安全重置。

未登录访问 Admin API 必须返回 401 或跳转登录；已登录但角色权限不足必须返回 403。不得只依赖前端隐藏菜单、隐藏路由或禁用按钮。

### 权限要求

| 功能 | ADMIN | FRONT_DESK |
| --- | ---: | ---: |
| Reservation 查看、搜索、处理 | 是 | 是 |
| Assign／Change Room | 是 | 是 |
| Guarantee 记录 | 是 | 是 |
| Check-in／Check-out／No-show | 是 | 是 |
| Availability、Hold、Maintenance | 是 | 是 |
| 每日房价与批量房价 | 是 | 是，除非项目另设更严格配置 |
| Room 床型、容量、公开状态 | 是 | 默认否 |
| Tax、Site Settings、Email Settings | 是 | 否 |
| 图片上传与排序 | 是 | 可按业务授权，默认仅 ADMIN |
| 用户与角色管理 | 是 | 否 |
| Audit Log 查看 | 是 | 按需要只读 |
| Confirm Without Card Guarantee | 是 | 否 |

如实现时调整默认权限，必须在 README 与权限表中明确记录，不得出现前端显示无权限但 API 实际可调用的情况。

---

## 26. Admin Dashboard

显示 Today：

- Arrivals
- Departures
- In-house
- Reservation Requests
- Awaiting Guarantee
- Confirmed
- Available Rooms
- Occupied
- Out of Service

“Today”按 America/Vancouver 计算。

各项数字必须来自同一库存和状态规则，不得 Dashboard 显示 Available、Calendar 却显示 Occupied。

点击指标可进入对应筛选结果。

---

## 27. Reservation Management

搜索：

- Reservation #
- Name
- Phone
- Email

Filters：

- Date
- Status
- Room
- Room Type
- Kitchen
- Pet
- Guarantee

支持：

- Edit
- Assign room
- Change dates
- Change price
- Confirm early check-in
- Change room
- Notes
- Guarantee
- Hold／Release Hold
- Confirm
- Decline
- Cancel
- Check in
- Check out
- No show
- Resend Email
- Copy SMS

后台详情页应根据当前状态显示合法的主要下一步操作。不可用的操作应禁用并说明原因，或不显示；不得让管理员点击后才出现不明错误。

Confirm 按钮只有满足以下条件才可用：

- 已分配合法房间；
- 无库存冲突；
- 价格快照可生成；
- Guarantee 已满足，或 ADMIN 完成 Override；
- 当前状态允许 Confirm。

---

## 28. Room Management 与 Maintenance

Admin → Rooms 列表显示：

- Room
- Photo Thumbnail
- Beds
- Kitchen
- Capacity
- Status
- Tonight Rate
- Occupancy

点击 Room 显示：

- Room Information
- Photos
- Rates
- Reservations
- Maintenance

Maintenance／Out of Service 必须占用对应日期库存。

不得允许直接把存在受影响 Confirmed 预订的房间设为 Maintenance 后不作处理。系统必须：

- 阻止操作并提示受影响预订；或
- 要求先换房／解决冲突，再继续。

Maintenance 结束后及时释放库存。Room Active、Bookable、Public、Maintenance 和当前 Occupancy 是不同概念，不得混为一个手写字段。

---

## 29. Availability Calendar 与 Rate Calendar

Availability Calendar：

- 纵向 Rooms；
- 横向 Dates；
- 显示 Available、Held、Confirmed、Checked In、Maintenance；
- 点击查看 Reservation、Price、Guest、Status。

Room 13 可以在授权内部管理视图出现，但不得进入公共库存。

Rate Calendar 支持：

- Rooms
- Date Range
- Rate
- 多房间批量设置

Calendar、Dashboard、Public Availability 和 Confirm 冲突检查必须共享同一库存服务或同一套核心规则，禁止各自编写相互矛盾的逻辑。

---

## 30. Contact、Contact Actions 与 FAQ

Contact 显示：

- Address
- Phone
- Text
- Email
- 24-Hour Front Desk
- Standard Check-in 2 PM
- Early check-in potentially available from 12 PM by arrangement
- Check-out 11 AM
- 地图导航

Contact Actions：

- Call：`tel:2503782140`
- Text：`sms:3476305076`
- Email：`mailto:ranchlandmotel2379@gmail.com`

地图链接必须指向真实地址或可靠地图搜索，不得使用空链接。

FAQ 至少包括：

### What time is check-in?

> Standard check-in begins at 2:00 PM. Early check-in may be available from 12:00 PM by arrangement with the front desk and subject to room availability.

### What time is check-out?

> Check-out is at 11:00 AM. Please contact the front desk if you need to request a later departure.

### Do you have kitchen rooms?

说明仅部分房间有厨房，可在 Request 中选择偏好或硬性要求，最终由 Motel 确认。

### Are pets allowed?

说明有 Pet-friendly rooms，当前费用和可用性联系前台。

### Do you have parking?

说明 Free Parking，适用于普通汽车、SUV、Pickup；不宣传大型卡车、Semi 或 Trailer Parking。

### Do I pay online?

说明 Pay at Property，V1 不在线支付；可能需要有效信用卡担保，由前台另行安排。

### Is my reservation confirmed immediately?

说明提交的是 Request，只有收到 Motel Confirmation 后才确认。

### Can I arrive late?

说明晚到请提前联系前台安排钥匙领取。

---

## 31. SEO 与 Accessibility

SEO 针对：

- Merritt motel
- Motel in Merritt BC
- Merritt accommodation
- Pet friendly motel Merritt
- Kitchen motel Merritt
- Affordable motel Merritt
- Ground floor motel Merritt

包含：

- Meta
- OpenGraph
- Structured Data
- Sitemap
- robots.txt

Structured Data 不得编造评分、评论、星级、价格或设施。

网站自身 Accessibility：

- Semantic HTML
- Keyboard Navigation
- Alt Text
- Focus
- Labels
- Contrast
- Screen Reader Support
- 所有 Room Photos 支持 Alt Text
- Lightbox、表单错误、菜单和弹窗可键盘操作
- 不仅靠颜色表达 Availability 或 Reservation 状态

不宣传 Motel physical wheelchair accessibility。

---

## 32. Site Settings

Admin 可修改：

- Motel Name
- Address
- Phone
- Text
- Email
- Standard Check-in
- Earliest Early Check-in
- Check-out
- From Price
- Front Desk Hours
- Hero Text
- Hero Image
- Gallery
- Pet Copy
- Late Arrival Copy
- Amenities
- Taxes
- Email Settings

设置修改应持久化并记录必要审计。Email 密码、API Key 等 Secret 不得以明文回显到普通设置页面或写入日志。

GA4 提供可配置开关，不硬编码追踪 ID；不收集信用卡敏感数据。

### Admin 后台真实接入与运行保证（Release Blocker）

Admin 后台必须是完整全栈功能，不是独立静态页面、演示数据面板或只有外观的 CMS Mockup。以下要求全部是发布阻断条件：任何一项不通过，都不得声称 Admin 已完成。

#### A. 统一数据链路

所有 Admin 管理功能必须遵循真实数据链路：

```text
Admin 页面提交
→ 真实服务端 API
→ 服务端认证、授权和业务验证
→ 写入真实数据库或对象存储
→ 返回真实保存结果
→ Admin 重新读取并显示已保存数据
→ Public Website 从同一数据源读取适用内容
```

不得出现：

- 点击 Save 只显示成功提示但没有实际写入；
- 数据只存在 React State、浏览器 `localStorage` 或当前页面；
- Admin 使用一套演示数据，Public Website 使用另一套硬编码内容；
- 上传图片只在后台临时预览，刷新后消失；
- 后台数字、房态或预订列表由固定 Mock Data 生成；
- 需要修改代码或重新部署才能完成日常内容、图片、房价和房态更新。

#### B. 公共官网与后台使用同一数据源

至少保证：

- Home Hero Text、Hero Image 和 Homepage Gallery 来自 Site Settings／Site Media；
- Room Type Cards、房间配置、容量、Kitchen 和公开状态来自 Rooms／Room Types；
- Public Availability 使用与 Admin Calendar 相同的 Reservations、Holds、Maintenance 和 Rooms 数据；
- Public Price 使用与 Admin Rate Calendar 相同的 Daily Rates 和价格计算规则；
- Admin 保存后，公共页面重新加载能够读取最新内容；如使用缓存，必须有合理失效或更新机制。

允许保留安全的初始 Seed／Fallback，但 Admin 已保存的数据必须优先生效，不得被硬编码默认值永久覆盖。

#### C. 持久化与运行要求

- 页面刷新、浏览器关闭、退出后重新登录，数据仍然存在；
- 服务重启后，业务数据和管理员账号仍然存在；
- 保存新版本或重新发布网站时，不得清空既有数据库、上传图片或管理员账号；
- 上传文件进入真实对象存储，数据库保存文件 Key 和关联关系；
- Migration 与 Seed 可重复执行或有明确安全策略，不得无意重复创建管理员或覆盖业务数据；
- Admin API 在数据库、存储或邮件服务失败时返回真实错误，不得伪造部分成功。

#### D. Admin 操作反馈与可靠性

- 所有表单具有 Loading、Saving、Success、Validation Error 和 Server Error 状态；
- 保存成功后显示从服务端读回的真实数据；
- 保存失败不得把界面伪装成已保存；
- 删除、覆盖、停用房号、Confirm、Cancel 等高风险操作需要适当确认；
- 重复点击 Save 不得造成重复记录或破坏排序、Cover 等约束；
- 所有 Admin 路由在直接访问、刷新和浏览器前进后退时可正常运行，不得刷新后 404 或丢失应用状态。

#### E. 必须实际执行的 Admin 端到端验收

交付前必须在真实运行环境完成以下操作，并核对公共页面、数据库读回结果或等价运行证据：

1. 初始化或创建首个 ADMIN，使用真实账号登录并退出；
2. 未登录访问 `/admin` 和 Admin API，确认被正确阻止；
3. 修改 Hero Text，保存后打开公共 Home，确认文案改变；
4. 上传 Hero 图片并设为当前 Hero，确认公共 Home 显示新图片，刷新后仍存在；
5. 上传房间照片、设置 Cover、调整顺序，确认公共 Room Type Gallery 同步更新；
6. 修改某 Room 某日期价格，确认 Admin Rate Calendar 与 Public 查询使用相同价格；
7. 修改一项 Site Setting，换浏览器或无痕窗口访问公共网站，确认修改持久化；
8. 创建一个 Reservation Request，在 Admin 中查看、分房、记录 Guarantee、Confirm，确认库存和价格快照真实更新；
9. 使用 FRONT_DESK 尝试访问 ADMIN-only 页面和直接调用对应 API，确认前端与服务端都拒绝；
10. 重启服务或进行等效冷启动，重新登录并确认账号、设置、照片、房价和预订均未丢失；
11. 检查 Audit Log，确认上述关键修改记录真实存在。

只展示后台截图、只看到 Save Success、只验证前端状态或只检查编译通过，均不算通过上述验收。

#### F. 交付说明

README 必须说明：

- Admin 的实际访问路径；
- 首个 ADMIN 的安全初始化方法；
- 如何创建 FRONT_DESK、修改密码和停用账号；
- 数据库、对象存储和邮件服务所需环境变量；
- 本地／预览／正式运行时的启动顺序；
- 已实际验证的 Admin 功能和任何仍未完成的限制。

不得向最终用户虚构登录地址、默认密码或已验证结果。

---

## 33. 技术架构与运行平台适配

优先检查现有项目：

- 新项目建立完整结构；
- 已有项目不无必要推倒重写；
- 复用已有数据库、认证、存储和设计体系。

推荐技术方向：

- Frontend：React＋TypeScript＋Tailwind CSS；
- 独立部署项目可采用 Next.js；
- Backend：与运行平台匹配的真实服务端 API；
- Database：生产级关系数据库；独立部署可使用 PostgreSQL；
- ORM：Drizzle 或 Prisma，或现有项目已采用的等价方案；
- 图片存储：抽象 `MediaStorageService`；
- 生产上传文件使用平台对象存储或 S3／Cloudflare R2／兼容对象存储。

若在特定全栈构建平台执行，应使用该平台真正支持的后端、云数据库、认证和对象存储能力，不得为了坚持某个框架而交付无法运行的项目。

`MediaStorageService` 至少抽象：

- upload()
- delete()
- getPublicUrl()／受控访问 URL
- generateThumbnail() 或等效图片优化流程

这样未来可以切换 Local（仅适当开发环境）、平台 Object Storage、S3、Cloudflare R2。

不要把上传图片永久依赖 Git repository。代码导出后如需自主部署，需自行配置数据库、认证、存储和邮件服务，不得假设平台托管能力会自动随代码迁移。

---

## 34. 数据库实体与核心约束

至少建立或等价实现：

- users
- rooms
- room_types
- media
- room_media
- room_type_media
- site_media
- room_daily_rates
- tax_rules
- reservations
- reservation_guests
- room_holds
- reservation_price_items
- reservation_price_snapshots／confirmation_versions
- reservation_guarantees
- reservation_status_history
- audit_logs
- site_settings
- email_logs

根据实现可增加：

- maintenance_blocks
- idempotency_keys
- reservation_events
- media_variants

### 必要约束与索引

- Reservation Number 唯一；
- Room Number 唯一；
- Room Type、Room、Media 外键有效；
- 每个 Room／Room Type 最多一个 Cover；
- Daily Rate 对 Room＋Date 有明确唯一或版本策略；
- Hold 的日期、状态、过期时间完整；
- Reservation 的 Assigned Room、日期、状态和金额可查询；
- 常用搜索字段、日期和状态建立合理索引；
- 金额使用定点小数或最小货币单位，不使用浮点误差计算；
- 重要时间戳、操作人和状态历史不可随意丢失。

---

## 35. 防止 Overbooking 的事务要求

“Confirm 前重新检查”是必要条件，但不是充分条件。

以下操作必须在同一数据库事务中完成冲突检查与写入，并使用适当的行锁、串行化、条件更新或数据库约束：

- Confirm Reservation；
- Change Dates；
- Change Room；
- Create／Extend Active Hold；
- Create Maintenance Block。

必须防止两个管理员同时 Confirm 同一房间同一日期，双方都因先读到“无冲突”而成功。

冲突检查至少覆盖：

- CONFIRMED
- CHECKED_IN
- ACTIVE 且未过期 HOLD
- 有效 MAINTENANCE

任何修改房间或日期的操作都必须重新检查，不得因为预订以前确认过就跳过。

事务失败时不得出现：

- Reservation 已 Confirmed 但价格快照未保存；
- Hold 已创建但状态未更新；
- Room 已换但旧库存未释放；
- 状态已变更但审计记录缺失（审计应与业务操作保持合理一致性）。

---

## 36. Security、Spam Protection 与 Privacy

必须实现与项目架构相适应的：

- Server-side validation
- CSRF protection where needed
- Rate Limit
- Input Sanitization／安全输出编码
- Secure Cookies
- Password Hash
- Authorization
- Audit Logs
- 参数化数据库访问
- 文件上传授权与真实类型校验
- 公共／内部媒体访问控制
- 邮件与表单防滥用

Reservation Form：

- Honeypot
- Rate Limit
- Optional CAPTCHA

只收必要资料，不主动收：

- Passport
- Driver Licence
- DOB

信用卡敏感数据绝不能进入系统。日志不得记录完整表单中的敏感字段、认证 Secret、完整卡号或 CVV。

---

## 37. Audit Logs

至少记录：

- Room assignment／change
- Price change
- Price snapshot／confirmation version
- Guarantee
- Confirm
- Admin Override 与原因
- Decline
- Cancel
- Check-in／Check-out
- No-show
- Hold create／extend／release／expire
- Maintenance create／change／release
- Tax 与 Rate 修改
- Early Check-in approval
- Photo Upload／Delete／Reorder／Cover／Public 状态变化
- Site Settings 重要变化

每条日志尽量包含：

- user
- timestamp
- action
- entity_type／entity_id
- before／after 或必要差异
- reason（高风险操作）
- request correlation id（如适用）

Audit Log 不记录完整卡号、CVV、密码或 Secret。

---

## 38. Seed Data 与环境交付

初始化：

- Rooms 1–18；
- Room 13 Internal；
- 所有 Beds／Kitchen／Capacity；
- Room Types；
- From Price：CA$119；
- Standard Check-in：14:00；
- Earliest Early Check-in：12:00；
- Check-out：11:00；
- Address：2379 Nicola Ave, Merritt, BC, Canada；
- Call：250-378-2140；
- Text：347-630-5076；
- Email：ranchlandmotel2379@gmail.com。

交付包含：

- Migration；
- Seed；
- `.env.example`，只放变量名和安全示例，不放真实 Secret；
- README，说明运行、构建、数据库、存储、邮件、初始管理员、测试和部署边界；
- 可运行前后端；
- 实际数据库连接与持久化；
- 图片上传与存储配置说明；
- 邮件未配置时的明确行为。

---

## 39. V1 不实现

- Online credit card input
- Online payment
- Moneris integration
- Stripe Checkout
- Automatic SMS
- Automatic no-show charge
- OTA integration
- Booking.com sync
- Expedia sync
- AI pricing
- Loyalty Program
- Guest accounts
- 自动 Instant Confirmation

---

## 40. Future-Proofing

预留但不伪造完成：

- Hosted Tokenization
- Secure Card Guarantee Link
- Pre-Authorization
- Online Payment
- SMS
- OTA / Channel Manager
- Housekeeping
- Long-stay pricing
- Promo Codes
- Corporate Rates

扩展点不得影响 V1 的简单、安全和可运行性。

---

## 41. 必测业务测试

至少覆盖以下自动化测试或具有等价可重复验证证据：

### Availability 与库存

- Availability overlap；
- Checkout／Check-in same day 合法；
- Room 13 unavailable；
- Public／Bookable／Active 过滤；
- Maintenance blocking；
- Active Hold blocking；
- Expired／Released Hold 不 blocking；
- REQUESTED／REVIEWING 不 blocking；
- Confirmed 后 Hold 不重复占库存；
- 两个并发 Confirm 不得同时成功；
- Change Dates／Change Room 重新检查冲突。

### 人数与偏好

- Maximum occupancy；
- Infant exclusion；
- Adults 至少 1；
- Kitchen filter；
- Prefer Kitchen 不过滤无厨房房；
- Kitchen Required 只使用厨房房；
- 不得给 Kitchen Required 分配无厨房房。

### Reservation 与状态

- Reservation creation；
- Unique reservation #；
- 重复提交不生成重复 Request；
- 合法与非法状态转换；
- Room conflict；
- Guarantee requirement；
- Admin override 记录；
- Decline／Cancel／No-show 释放占用；
- Check-in／Check-out 前置状态。

### 价格与税

- Daily Rates；
- 多晚不同价格；
- Tax；
- 税率 Effective Date；
- 统一 rounding；
- Price Snapshot；
- 后续 Daily Rate／Tax 修改不影响旧 Confirmed Reservation；
- 确认后修改生成新版本并保留历史。

### Early Check-in

- 12 PM 前时间被拒绝或验证失败；
- 12 PM Early Check-in Request；
- 早于 2 PM 不自动批准；
- Early Check-in approval；
- Confirmation Email 显示最终批准时间。

### 权限与安全

- Authorization；
- FRONT_DESK 不得调用 ADMIN-only API；
- Image upload authorization；
- Public／private media；
- 不保存完整卡号／CVV；
- 表单服务端验证与 Rate Limit。

### 图片与邮件

- Room photo ordering 持久化；
- Cover photo 唯一；
- Internal 图片不会因关联而公开；
- Email 成功与失败；
- Email 失败不回滚 Reservation；
- Resend；
- Confirm 重试不重复发送同版本邮件；
- Updated Confirmation 使用最新价格与入住时间。

---

## 42. UI、响应式与实际运行验证

Public 应具有真实 Motel 官网感，重点展示真实：

- 房间；
- 床型；
- 厨房；
- 卫生间；
- 外观；
- 停车便利。

Admin 采用商业型、扁平、快速操作设计。

响应式至少测试：

- 390
- 430
- 768
- 1024
- 1440
- 1920

要求：

- 房间照片在 Mobile 不横向溢出；
- Gallery 适合 Swipe；
- 触控目标可用；
- 所有关键表单有标签、错误和反馈；
- 所有弹窗、菜单、Lightbox 可关闭并支持键盘；
- 无死按钮、空链接或假交互；
- 页面无控制台错误和资源 404；
- 图片 Lazy Load、Responsive Srcset、合理压缩并避免 CLS；
- 核心流程至少进行一次冷启动验证。

不能只以“编译通过”或“页面能打开”作为完成依据。必须实际触发核心流程并核对数据库或后台结果。

---

## 43. 完成标准

项目完成必须满足：

1. Public website 正常；
2. Mobile responsive；
3. 17 间公开 Room 数据正确；
4. Room 13 不进入公开库存；
5. 日期查询与半开区间规则正常；
6. Availability 使用统一占用规则；
7. Reservation Request 可提交并防止重复提交；
8. Unique Reservation Number；
9. Admin 查看、搜索和筛选请求；
10. Admin 分配 Room；
11. Admin 可设置、释放和过期处理 Hold；
12. Admin 记录 Card Guarantee；
13. 状态机阻止非法跳转；
14. Admin Confirm 与 ADMIN Override 规则正常；
15. Confirm 采用事务防止并发 Overbooking；
16. Confirm 后发送 Email，失败可 Resend 且不回滚预订；
17. Copy SMS 使用最终确认信息；
18. 每日单独定价与批量定价正常；
19. 税率后台配置；
20. Confirm 保存 Price Snapshot，后续修改保留版本；
21. Availability Calendar；
22. Maintenance 与已有预订冲突处理；
23. 不保存完整卡号／CVV；
24. Audit Log；
25. 权限同时在前端和服务端生效；
26. Migration；
27. Seed；
28. `.env.example`；
29. README；
30. Room Type 支持多张照片；
31. 每个具体 Room 支持多张照片；
32. Admin 可上传、更换、排序照片；
33. 首页 Hero 可替换；
34. Homepage Gallery 可维护；
35. Internal 图片不会意外公开；
36. Lightbox；
37. Alt Text；
38. Responsive Image；
39. Early Check-in 从 12 PM 开始只能作为 Request；
40. Admin 可批准实际 Check-in Time；
41. Confirmation Email 显示最终批准 Check-in Time；
42. 邮件和短信文案不包含敏感卡数据；
43. 公共查询明确“可申请但未确认、未锁房”；
44. 核心测试和真实运行验证通过；
45. `/admin` 与 `/admin/login` 可真实访问，登录、退出、Session 过期和首个 ADMIN 初始化正常；
46. Admin 所有可见管理操作均连接真实 API，不存在 Mock Data、假保存或仅前端状态更新；
47. Admin 与 Public Website 使用同一数据库和业务服务，修改 Hero、Site Settings、照片或 Daily Rate 后公共网站能读取新值；
48. Admin 数据在刷新、重新登录、服务重启和网站版本更新后仍然保留；
49. 未登录和越权访问 Admin API 均被服务端拒绝；
50. 已实际完成本指令规定的 Admin 端到端验收，而非仅提供后台截图；
51. README 提供真实 Admin 路径、首个管理员初始化方法及运行配置，不包含虚构账号或公共默认密码。

---

## 44. Agent 工作方式

先检查现有项目。已有项目不要无必要推倒重写。

优先顺序：

1. Database 与核心约束
2. Availability、Hold、Maintenance 与 Reservation Logic
3. 事务性 Overbooking Protection
4. Rooms 与 Room Types
5. Admin Authentication 与 Permissions
6. Reservation Management 与状态机
7. Rates、Taxes 与 Price Snapshot
8. Guarantee 与 Early Check-in
9. Email 与 SMS Copy
10. Media／Photos 与对象存储
11. Public Site
12. Visual Polish
13. 全业务测试与冷启动验证

先完成一个端到端 Vertical Slice：

```text
查询房型
→ 创建 Request
→ Admin 查看
→ 分房
→ Hold／Guarantee
→ Confirm
→ 占用库存
→ 保存价格快照
→ 发送或诚实记录 Email 结果
```

然后扩展图片、批量房价、设置、SEO 和视觉细节。不得先完成大量漂亮页面，却留下假数据库、假预订或假后台。

遇到普通技术细节自行合理决定。不得擅自编造：

- Cancellation Policy
- Pet Fee
- No-show Fee
- Tax Rate
- Credit Card Rules
- Reviews
- Star Rating
- Amenities

遇到业务规则不清时，优先采用本指令中的安全和一致性原则；不要静默改变库存、金额、权限或确认语义。

---

## 45. 最终业务流程

### Guest

```text
Visit website
→ See actual motel and room photos
→ Select dates and guests
→ Check room types available to request
→ Review room gallery and estimated price
→ Select preferred room type
→ Request kitchen if needed
→ Request early check-in if needed, earliest 12:00 PM
→ Submit Reservation Request
→ Receive Request Number
→ Understand room is not held or confirmed yet
```

### Front Desk

```text
Review
→ Assign eligible Room
→ Recheck conflicts
→ Optionally Hold Room with expiry
→ Approve or reject requested early check-in
→ Contact guest
→ Obtain credit card guarantee through existing card provider
→ Mark guarantee verified
→ Confirm Reservation
```

ADMIN 可以 Confirm Without Card Guarantee，但必须记录 Override 原因和审计信息。

### System

```text
Atomically recheck inventory
→ Confirm Reservation
→ Convert or consume Hold
→ Block inventory
→ Save room, tax and nightly price snapshot
→ Save confirmation version
→ Save confirmed check-in time
→ Write status history and audit log
→ Send confirmation email with idempotency protection
→ Log email success or failure without changing confirmation incorrectly
```

### Guest

```text
Receive Confirmation
→ Arrive at approved time
→ Pay at Property
```

整个 V1 不得接触完整信用卡号或 CVV。

房间图片必须作为网站的重要内容资产设计，不能只是临时占位元素；任何内部照片都不得因分配到公共图库而被意外公开。
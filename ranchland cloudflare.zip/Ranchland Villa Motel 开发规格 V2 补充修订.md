# Ranchland Villa Motel 开发规格 V2 —— 补充与修订

> 本文件是《Ranchland Villa Motel 官网与预订管理系统开发总指令》（V1）的补充规格。
> 与 V1 冲突之处，**以本文件为准**。V1 未被提及的条款全部保留有效。

---

# A. 业主确认的修订决定

## A1. 婴儿规则（修订 V1 §19）

- 2 岁以下婴儿不计入 Maximum Occupancy，仍保存数量。
- **婴儿数量不设上限**，不做额外校验，不需要前台审核标记。

## A2. 公开 "From" 价格（修订 V1 §12、§13、§20、§23）

- 公开的 "From CA$xxx/night" **不自动计算**，由 Admin 在 site_settings 中手动维护（对应 V1 §69 Site Settings 的 From Price 项）。
- 参考值：淡季约 CA$109，旺季约 CA$209，由 Admin 按季节手动调整。
- V1 §77 Seed Data 的 From Price CA$119 仅作为**初始种子值**，上线前由 Admin 按季节改为实际值。
- 该价格仅为宣传展示，真实价格以逐晚房价和确认价格快照为准。

## A3. No-Show 收费（修订 V1 §40）

- No-Show **收取当晚（首晚）房费**。
- 执行方式：前台通过电话取得客人信用卡号，使用现有 credit-card terminal / virtual terminal 收取，**网站不接触、不保存完整卡号与 CVV**。
- 系统在 NO_SHOW 状态下显示"应收首晚费用"金额（来自价格快照）供前台参考，并允许记录：
  - charge_status（Pending / Charged / Waived / Failed）
  - charged_amount
  - provider_reference（可选）
  - notes
- 系统自身不自动扣款（与 V1 §78 "第一版不实现 Automatic no-show charge" 一致）。
- 说明：首晚房费标准由业主已确认（即价格快照中的首晚房费），不属于 V1 §83 禁止"擅自编造 No-show Fee"的情形；除首晚房费外不得另设其他 No-show 罚金。

## A4. 顶部快捷按钮（确认 V1 §3）

- Call / Text / Check Availability 三个快捷入口在手机端和桌面端**均保留**。

## A5. Room 18 公开出租（确认 V1 §17、§20）

- Room 18（1 Double, 无厨房）包含在 17 间公开出租房内。
- 公共房型列表包含 **Double Room（1 Double Bed）**，与 Queen Room、Two Double Beds、Two Queen Beds、Three-Bed / Family Room 并列。

---

# B. 库存规则

## B1. 占用库存的状态（唯一标准）

| 状态 / 记录 | 是否占用库存 |
|---|---:|
| REQUESTED | 否 |
| REVIEWING | 否 |
| AWAITING_GUARANTEE（无有效 Hold） | 否 |
| AWAITING_GUARANTEE（存在有效 Hold） | 是 |
| CARD_GUARANTEED | 仅当存在有效 Hold 时占用 |
| CONFIRMED | 是 |
| CHECKED_IN | 是 |
| 有效 Maintenance | 是 |
| DECLINED / CANCELLED / CHECKED_OUT / NO_SHOW | 否 |

- 公共页面文案必须说明：**查询到可申请房型，只代表目前可以提交申请，不代表房间已为客人保留。**

## B2. Hold 必须有时效

`room_holds` 必须包含：

- hold_expires_at
- released_at
- release_reason

规则：

- Hold 到期自动失效（可由定时任务释放，或查询时自动视为失效，二者选一并全局统一）。
- Hold 的默认有效期由 site_settings 配置（建议 24–48 小时），Admin 可逐条修改。
- Dashboard 显示"即将到期 / 已过期未处理"的 Hold 提醒。
- 预订转为 CONFIRMED 时，对应 Hold 转为正式预订占用，**不得重复计算库存**。
- Release Hold 必须记录操作人和时间（写入 audit_logs）。

## B3. 日期重叠判断（全局唯一公式）

采用"入住当天计入、退房当天不计入"的半开区间：

```text
已有 check_in < 新 check_out
并且
已有 check_out > 新 check_in
```

即：A 订 11 月 10 日 → 11 月 12 日，B 订 11 月 12 日 → 11 月 14 日，两者**不冲突**。退房当天允许下一位客人入住。

## B4. 原子防冲突

以下操作必须在**同一个数据库事务**内重新检查冲突后才能提交：

- 确认预订（Confirm）
- 修改入住或退房日期
- 更换房间
- 新增或延长 Hold
- 新增 Maintenance

推荐在数据库层面对（room_id, 住宿日期区间）建立排他约束（如 PostgreSQL exclusion constraint），不能只依赖应用层的"先查后写"。

## B5. Kitchen Preference 影响库存计算

- **No preference**：不要求厨房，使用全部该房型房间计算可申请库存。
- **Prefer a kitchen**：仅为偏好，不排除无厨房房间；在 Admin 端显示偏好标记。
- **Kitchen required**：只使用 kitchen = Yes 的房间计算可申请库存；Admin 端对该请求**突出显示**。

注意：Three-Bed / Family Room 只有 Room 3，Two Queen Beds 只有 Room 8，这类单一房间房型的 Hold 与冲突处理必须逐房精确判断。

## B6. Early Check-in 冲突提示

Admin 审批 Early Check-in（早于 2:00 PM）时，系统必须显示该分配房间前一晚的占用情况与前一单退房日期，供前台判断 12:00 PM 入住是否可行。系统只做提示，不自动拒绝。

---

# C. 状态规则

## C1. 状态转移表（唯一合法路径）

正常流程：

```text
REQUESTED → REVIEWING → AWAITING_GUARANTEE → CARD_GUARANTEED → CONFIRMED → CHECKED_IN → CHECKED_OUT
```

旁路流程：

| 转移 | 条件 |
|---|---|
| REQUESTED / REVIEWING → DECLINED | 允许，记录原因 |
| CONFIRMED 之前任意状态 → CANCELLED | 允许，记录原因；释放 Hold / 库存 |
| CONFIRMED → CANCELLED | 允许，记录原因；释放库存 |
| CONFIRMED → NO_SHOW | 允许；显示应收首晚费用（见 A3） |
| AWAITING_GUARANTEE → CONFIRMED | **仅 Admin Override**，弹窗确认并记录 user / timestamp / reason |
| CHECKED_IN → CHECKED_OUT | 正常退房；提前退房同样走此转移 |

- 每次状态变更必须先校验"当前状态是否允许转到目标状态"，不能仅校验按钮权限。
- 每次状态变更必须写入 reservation_status_history（旧状态、新状态、操作人、时间、原因）。
- CHECKED_IN 不允许直接回退到 CONFIRMED；分错房应通过"更换房间"操作处理并记录。

## C2. Guarantee 状态单一数据源

- Reservation 的 `CARD_GUARANTEED` 状态**只能由有效的 Guarantee 记录驱动**：当 reservation_guarantees 中存在 guarantee_status = VERIFIED 或 PREAUTHORIZED 的记录时，预订方可进入 CARD_GUARANTEED。
- 管理员不手动修改两套状态；担保进度以 reservation_guarantees 为准。
- CONFIRMED 的前提（除 Admin Override 外）：已分配房间 + 无日期冲突 + 存在有效 Guarantee 记录。

## C3. 状态变更后的库存联动

Cancel、Decline、No-Show、提前退房、Maintenance 结束后，必须立即重新计算对应房间在受影响日期内的房态与可申请库存。

---

# D. 价格与税费规则

## D1. 计算口径（全局统一）

- 每晚房价按**住宿日期**确定（room_daily_rates 优先，缺省用 default_rate）。
- 税费按**各住宿夜对应的有效税率**计算（按 tax_rules 的 Effective Date / End Date 匹配每个住宿夜），不按确认日期取值。
- Request 页面显示 **Estimated Total**（预估价，文案注明最终以确认为准）。
- Confirm 时生成价格快照，写入 reservation_price_items（逐晚房价 + 各税种 + 费用项目 + 合计）。

## D2. 确认后的修改

- Confirm 后修改日期、房间或价格，生成**新的价格快照版本**，保留旧版本与审计记录，不覆盖。
- 管理员不直接修改总价，只能修改每晚价格与费用项目（如 Pet Fee），系统重新汇总。
- 舍入规则：各税种按订单汇总金额计算后四舍五入到分，全局统一，不逐晚单独舍入。
- Pet Fee 及其他费用是否计税，由 tax_rules 中每个税种配置（applies_to_fees 标志），不硬编码。

## D3. Request 提交后房价变化的处理

- Request 阶段显示的价格仅为预估。
- 前台 Review 时显示"当前逐晚房价"与"客人提交时预估价"的差异（如有），Confirm 以**确认时刻**的房价为准并生成快照，除非管理员手工调整。

---

# E. 公共网页流程

## E1. 预订流程（固定）

```text
选择日期和人数
→ 查询可申请房型（按房型聚合）
→ 查看房型照片、条件和预估价格
→ 填写 Reservation Request（自动带入日期、人数、房型、厨房偏好）
→ 提交时再次验证日期、人数和库存
→ 创建 REQUESTED
→ 返回 Request Number
→ 发送"已收到，但未确认"邮件
```

细则：

- 公共可用性按**房型聚合**显示（Available / Limited / Unavailable），不暴露具体房间号和逐房库存。
- 从查询结果进入表单时保留已选条件。
- 提交时若库存已变化，明确告知客人，不假装房间仍被保留。
- 无结果时提供：修改日期 / 修改人数 / 电话联系前台的引导。
- 表单提交失败时保留用户已填写内容。
- 防重复提交：提交按钮点击后禁用 + 服务端幂等处理，不得产生两个 Request。
- Request Number 全局唯一，公共页面与所有邮件使用同一编号。
- 按钮文案使用 **Request This Room Type**，不使用 "Request This Room"（覆盖 V1 §12、§70 中的按钮文案），避免客人误以为在申请具体房号。

## E2. 时区与表单校验

- 全局使用 motel 所在时区 **America/Vancouver** 判断"今天"、Hold 过期时间与邮件时间。
- 校验规则：
  - 入住日期不能早于当天；
  - 退房日期必须晚于入住日期；
  - 至少 1 名成人；
  - 儿童、婴儿数量不能为负数；
  - 成人 + 2 岁以上儿童之和不得超过所选房型 Maximum Occupancy（婴儿不计，且不设上限，见 A1）；
  - Preferred Check-in Time 不得早于 12:00 PM；
  - 早于 2:00 PM 永远只是 REQUEST，提示由前台确认；
  - 晚于标准时间的到达时间正常填写，不视为 Early Check-in，仅作为 Late Arrival 备注。
- 表单增加 **Estimated Arrival Time（预计到达时间）** 字段，用于晚到钥匙交接安排，与 Preferred Check-in Time 分开。

## E3. 多间房 / 连接房需求

- V1 表单每次申请一个房型。客人需要多间房或连接房（Room 1 + Room 2）时，在 Special Requests 中说明，文案引导：
  > Need multiple rooms or connecting rooms? Let us know in Special Requests or contact the front desk.
- Admin 端允许前台为一个 Reservation 备注关联的第二间需求，具体安排由前台人工处理（V1 不做一单多房的自动库存扣减）。

---

# F. 后台规则

## F1. 权限矩阵

| 功能 | ADMIN | FRONT_DESK |
|---|---:|---:|
| 处理预订、分房、入住、退房 | 是 | 是 |
| 记录担保结果 | 是 | 是 |
| 设置 / 释放 Hold、Maintenance | 是 | 是 |
| 修改每日房价 | 是 | 是 |
| 修改床型、容量、房间公开状态 | 是 | 否 |
| 修改税率、网站设置、邮件设置 | 是 | 否 |
| 管理管理员账号 | 是 | 否 |
| Confirm Without Guarantee（Override） | 是 | 否 |
| 维护公开 "From" 价格 | 是 | 否 |

## F2. 操作按钮按状态显示

后台预订详情页根据当前状态只显示合法的下一步操作（依 C1 状态转移表），不始终展示全部按钮。例如 Confirm 仅在满足"已分房 + 无冲突 + 有效担保或 Admin Override"时可用。

## F3. Maintenance 冲突保护

对已有 CONFIRMED / CHECKED_IN / 有效 Hold 占用日期的房间设置 Maintenance 时：

- 系统阻止直接保存，并列出受影响的预订；
- 要求先为受影响预订换房或完成处理，才能继续；
- 全部阻止与换房操作写入 audit_logs。

---

# G. 图片与邮件规则

## G1. 图片公开范围

- 标记为 Internal 的房间照片被分配到 Room Type Gallery 后，**不因此自动公开**。公共网站只能读取 room_type_media 中明确关联且 media 本身允许公开的图片。
- 每个房间 / 房型最多一张 Cover（设置新 Cover 自动取消旧 Cover）。
- 删除仍被引用的照片时，提示影响范围（哪些房间 / 房型 / 首页区块在使用）。
- 公共图片的 Alt Text 与 Caption 不得包含内部备注信息。
- 上传时校验真实文件类型（magic bytes）与大小，不只看扩展名。

## G2. 邮件防重复与版本

- 以"邮件类型 + 预订 + 价格快照版本"作为防重复依据，防止管理员重复点击 Confirm 发出多封相同确认邮件。
- 预订发生重要变更（日期、房间、价格、确认入住时间）后，发送标记为 **Updated Confirmation** 的新邮件，不重发旧内容。
- 邮件发送失败**不阻塞**状态变更；email_logs 记录失败，Dashboard 显示"待重发"提醒，支持手动重发。

---

# H. 数据库实体补充

在 V1 §61 基础上补充字段：

- `room_holds`：增加 hold_expires_at、released_at、release_reason、created_by
- `reservation_price_items`：增加 version（快照版本号）、superseded_by
- `reservations`：增加 estimated_arrival_time、no_show_charge_status、no_show_charged_amount
- `tax_rules`：增加 applies_to_fees
- `site_settings`：增加 public_from_rate（公开 From 价格，见 A2）、default_hold_hours

---

# I. 实施优先级建议

1. **先锁定**：B1–B4（库存占用 + 原子防冲突）、C1–C2（状态转移 + 担保单一数据源）、D1（价格口径）。
2. **其次**：E1–E2（公共流程与校验）、F1–F3（权限与 Maintenance 保护）。
3. **最后**：G1–G2（图片公开范围、邮件防重）与各页面 UI 细节。

以上规则锁定后，V1 + V2 即为可支撑严谨开发的完整规格。

---

# J. 与 V1 §64–83 的对接与补充

V1 后半部分（§64 Date Rules 至 §83 Agent 工作方式及最终业务流程）全部保留有效。以下为对接关系与必要补充。

## J1. 可用性计算（细化 V1 §71 Availability Logic）

公共与后台的可用性统一按以下输入计算，不得各写一套：

- Public Rooms：仅 public = true 且 active = true 的房间（Room 13 永远排除）；
- Capacity：成人 + 2 岁以上儿童之和 ≤ max_occupancy（婴儿不计、不设上限，见 A1）；
- Kitchen：按 B5 的 Kitchen Preference 规则过滤；
- Reservations / Holds / Maintenance：按 B1 占用状态表判断，重叠判断统一用 B3 半开区间公式（即 V1 §64 "Checkout 当天可再次入住"）。

## J2. 安全与隐私（补充 V1 §65–68）

V1 的 Server-side validation、CSRF、Rate Limit、Input Sanitization、Secure Cookies、Password Hash、Authorization、Audit Logs、Honeypot、Optional CAPTCHA、最小化收集、GA4 开关全部保留，另补充：

- Rate Limit 至少覆盖：Reservation 提交、Admin 登录、图片上传；
- 日志、Analytics、错误上报中不得包含卡号、CVV 及表单中的敏感个人信息（与 V1 §26 一致）；
- 后台会话超时自动登出，密码哈希使用业界标准算法（bcrypt / argon2）。

## J3. Audit Logs 补充事件（扩展 V1 §74）

在 V1 已有事件（分房、价格、担保、确认、取消、No-show、税、费率、早入住审批、照片上传/删除/变更）之上，新增必须记录：

- Hold 创建、延长、释放、到期自动失效；
- Confirm Without Guarantee Override（user / timestamp / reason）；
- 价格快照新版本生成及修改内容；
- Maintenance 设置、结束，以及因冲突被阻止的操作；
- No-show 首晚费用收取记录（charge_status / charged_amount / provider_reference）；
- 公开 From Price 修改；
- 邮件重发。

## J4. 测试用例补充（扩展 V1 §81）

V1 测试清单全部保留，新增：

- Hold 到期后自动失效，房间恢复可申请；
- 两个并发 Confirm 同一房间同一晚，**只能一单成功**（B4 原子性）；
- Kitchen required 时无厨房房间不计入可申请库存（B5）；
- 非法状态转移被拒绝（如 CHECKED_OUT → CONFIRMED、无担保且无 Override 时 Confirm）（C1、C2）；
- 确认后改日期生成新价格快照版本，旧版本保留可查（D2）；
- 不同住宿夜适用不同税率时逐夜取税率（D1）；
- 重复点击 Confirm 不产生重复确认邮件；重要变更后发送 Updated Confirmation（G2）；
- Internal 图片分配到 Room Type Gallery 后公共端仍不可见（G1）；
- 有 CONFIRMED 预订的房间设置 Maintenance 被阻止并列出受影响预订（F3）；
- NO_SHOW 状态显示应收首晚费用，金额等于价格快照首晚房费（A3）；
- 公开 From Price 为 site_settings 手动值，不随每日房价自动变化（A2）。

## J5. 完成标准补充（扩展 V1 §80）

在 V1 的 35 条验收标准之上，新增：

36. Hold 有失效时间并可自动失效；
37. 并发 Confirm 不会产生 Overbooking；
38. 状态转移按 C1 表校验并全部写入 status_history；
39. 担保状态由 Guarantee 记录单一驱动；
40. 价格快照版本化，历史版本可追溯；
41. Internal 图片不会泄漏到公共端；
42. 邮件失败不阻塞状态变更，可重发且防重复；
43. No-show 应收首晚费用可记录收取结果；
44. From Price 可由 Admin 手动维护；
45. Request Number 全局唯一，公共页与邮件一致。

## J6. 实施顺序对齐（衔接 V1 §83）

V1 的实施顺序（Database → Reservation Logic → Rooms → Admin → Availability → Email → Media → Public Site → Visual Polish）保留。其中：

- Database 阶段一并落地 H 部分的新增字段；
- Reservation Logic 阶段必须完成 B1–B4、C1–C2、D1–D3，再进入后续阶段；
- Availability 阶段实现 J1 的统一计算口径；
- Email 阶段实现 G2 防重复与 Updated Confirmation。
